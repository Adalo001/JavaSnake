Spampede README.txt

Please complete the template below, replacing the text between 
the ** symbols with your own text.

Parts of the project completed/not completed:

   ** 
      I complete the whole project! And some extra credit 
   **

Known bugs:  

   ** 
      I found some, but managed to fix most of them. 
   **

Extra features that were added:

   ** 
      I have the wall shrink over time! Approximately every 200 refreshes, the walls shrink and the play space gets smaller. 
   ** 

(Optional) Comments about this project:

	 *It was a fun project that was challenging but not counter intuitive. *

